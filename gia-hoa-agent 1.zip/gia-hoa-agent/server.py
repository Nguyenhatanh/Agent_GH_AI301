"""
Web server cho Agent Đánh Giá Chương Trình Bán Hàng — Công ty Gia Hòa.
Flask + Polling để theo dõi tiến trình pipeline.
"""

import json
import os
import sys
import threading
from pathlib import Path

import numpy as np

from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

# Thêm thư mục gốc vào path
sys.path.insert(0, os.path.dirname(__file__))

from tools.data_loader import validate_data
from tools.revenue_allocator import allocate_revenue
from tools.program_calculator import calculate_results
from tools.reconciler import reconcile_and_export

app = Flask(__name__, static_folder=".", static_url_path="")

UPLOAD_FOLDER = Path(__file__).parent / "data"
OUTPUT_FOLDER = Path(__file__).parent / "output"
UPLOAD_FOLDER.mkdir(exist_ok=True)
OUTPUT_FOLDER.mkdir(exist_ok=True)

# Trạng thái pipeline — frontend poll endpoint /api/status
pipeline_state = {
    "running": False,
    "current_step": 0,       # 0 = chưa chạy, 1-4 = đang chạy step đó
    "completed_steps": [],    # Danh sách step đã xong (1,2,3,4)
    "step_results": {},       # Kết quả từng step {1: {...}, 2: {...}, ...}
    "error": None,            # Lỗi nếu có
    "done": False,            # Pipeline hoàn tất
    "result": None,           # Kết quả cuối cùng
}
state_lock = threading.Lock()


def reset_state():
    """Reset trạng thái pipeline."""
    with state_lock:
        pipeline_state.update({
            "running": False,
            "current_step": 0,
            "completed_steps": [],
            "step_results": {},
            "error": None,
            "done": False,
            "result": None,
        })


def run_pipeline(file_path: str):
    """Chạy 4 bước pipeline, cập nhật trạng thái để frontend poll."""
    output_path = str(OUTPUT_FOLDER / "KetQua_GiaHoa.xlsx")
    state = {}

    try:
        # ── Step 1: Kiểm tra dữ liệu ──
        with state_lock:
            pipeline_state["current_step"] = 1

        state = validate_data(file_path)
        s = state["summary"]

        with state_lock:
            pipeline_state["step_results"][1] = {
                "tong_don": s["tong_don"],
                "don_hop_le": s["don_hop_le"],
                "don_khong_hop_le": s["don_khong_hop_le"],
                "ma_trong": s["ma_trong"],
                "ma_none": s["ma_none"],
                "so_dong_nhat_ky": len(state["nhat_ky"]),
            }
            pipeline_state["completed_steps"].append(1)

        # ── Step 2: Phân bổ doanh thu ──
        with state_lock:
            pipeline_state["current_step"] = 2

        state = allocate_revenue(state)
        sa = state["summary_phan_bo"]

        with state_lock:
            pipeline_state["step_results"][2] = sa.to_dict(orient="records")
            pipeline_state["completed_steps"].append(2)

        # ── Step 3: Tính kết quả ──
        with state_lock:
            pipeline_state["current_step"] = 3

        state = calculate_results(state)
        kq = state["ket_qua_chuong_trinh"]
        cols = [
            "promo_code", "program_name", "so_don",
            "doanh_thu_gop", "tong_doi_tra",
            "doanh_thu_thuan", "gia_von_thuan", "chi_phi_co_dinh",
            "phan_dong_gop", "bien_dong_gop_pct",
        ]

        with state_lock:
            pipeline_state["step_results"][3] = kq[cols].to_dict(orient="records")
            pipeline_state["completed_steps"].append(3)

        # ── Step 4: Đối soát & Xuất ──
        with state_lock:
            pipeline_state["current_step"] = 4

        state = reconcile_and_export(state, output_path)
        ds = state["doi_soat"]

        with state_lock:
            pipeline_state["step_results"][4] = {
                "doi_soat": ds["ket_qua"],
                "tong_phan_bo": ds["tong_phan_bo"],
                "tong_chua_phan_bo": ds["tong_chua_phan_bo"],
                "tong_doi_soat": ds["tong_doi_soat"],
                "sai_lech": ds["sai_lech"],
                "xuat_file": state["xuat_file"],
            }
            pipeline_state["completed_steps"].append(4)

        # ── Tổng hợp kết quả cuối ──
        kq = state["ket_qua_chuong_trinh"]
        programs = []
        for _, row in kq.iterrows():
            margin = row["bien_dong_gop_pct"]
            if margin >= 38:
                rec = "TIẾP TỤC"
                rec_reason = "Biên cao, hiệu quả tốt"
            elif margin >= 37.5:
                rec = "ĐIỀU CHỈNH"
                rec_reason = "Biên trung bình, cần tối ưu chi phí"
            else:
                rec = "ĐIỀU CHỈNH"
                rec_reason = "Biên thấp, chi phí/đơn cao"

            programs.append({
                "promo_code": row["promo_code"],
                "program_name": row["program_name"],
                "so_don": int(row["so_don"]),
                "doanh_thu_gop": float(row["doanh_thu_gop"]),
                "tong_doi_tra": float(row["tong_doi_tra"]),
                "doanh_thu_thuan": float(row["doanh_thu_thuan"]),
                "gia_von_thuan": float(row["gia_von_thuan"]),
                "chi_phi_co_dinh": float(row["chi_phi_co_dinh"]),
                "phan_dong_gop": float(row["phan_dong_gop"]),
                "bien_dong_gop_pct": float(margin),
                "khuyen_nghi": rec,
                "ly_do": rec_reason,
            })

        programs.sort(key=lambda p: p["bien_dong_gop_pct"], reverse=True)

        ds = state["doi_soat"]
        final = {
            "programs": programs,
            "summary": state["summary"],
            "doi_soat": {
                "ket_qua": ds["ket_qua"],
                "tong_phan_bo": float(ds["tong_phan_bo"]),
                "tong_chua_phan_bo": float(ds["tong_chua_phan_bo"]),
                "tong_doi_soat": float(ds["tong_doi_soat"]),
                "sai_lech": float(ds["sai_lech"]),
            },
            "output_file": output_path,
        }

        with state_lock:
            pipeline_state["result"] = final
            pipeline_state["done"] = True
            pipeline_state["running"] = False

    except Exception as e:
        with state_lock:
            pipeline_state["error"] = str(e)
            pipeline_state["running"] = False


# ── Routes ──

@app.route("/")
def index():
    return send_from_directory(".", "dashboard.html")


@app.route("/api/upload", methods=["POST"])
def upload():
    """Upload file Excel và chạy pipeline."""
    if pipeline_state["running"]:
        return jsonify({"error": "Pipeline đang chạy, vui lòng chờ"}), 409

    if "file" not in request.files:
        return jsonify({"error": "Chưa chọn file"}), 400

    f = request.files["file"]
    if f.filename == "":
        return jsonify({"error": "Tên file trống"}), 400

    if not f.filename.endswith((".xlsx", ".xls")):
        return jsonify({"error": "Chỉ chấp nhận file Excel (.xlsx, .xls)"}), 400

    filename = secure_filename(f.filename)
    filepath = str(UPLOAD_FOLDER / filename)
    f.save(filepath)

    reset_state()
    with state_lock:
        pipeline_state["running"] = True

    thread = threading.Thread(target=run_pipeline, args=(filepath,), daemon=True)
    thread.start()

    return jsonify({"status": "ok", "file": filename})


@app.route("/api/run-default", methods=["POST"])
def run_default():
    """Chạy pipeline với file mặc định."""
    if pipeline_state["running"]:
        return jsonify({"error": "Pipeline đang chạy, vui lòng chờ"}), 409

    default_file = str(UPLOAD_FOLDER / "Du_Lieu_Gia_Hoa.xlsx")
    if not Path(default_file).exists():
        return jsonify({"error": "Chưa có file dữ liệu mặc định"}), 404

    reset_state()
    with state_lock:
        pipeline_state["running"] = True

    thread = threading.Thread(target=run_pipeline, args=(default_file,), daemon=True)
    thread.start()

    return jsonify({"status": "ok", "file": "Du_Lieu_Gia_Hoa.xlsx"})


def sanitize(obj):
    """Chuyển numpy types → Python native để json.dumps không lỗi."""
    if isinstance(obj, dict):
        return {str(k): sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize(i) for i in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj


@app.route("/api/status")
def status():
    """Frontend poll endpoint — trả trạng thái hiện tại của pipeline."""
    with state_lock:
        return jsonify(sanitize({
            "running": pipeline_state["running"],
            "current_step": pipeline_state["current_step"],
            "completed_steps": pipeline_state["completed_steps"],
            "step_results": pipeline_state["step_results"],
            "error": pipeline_state["error"],
            "done": pipeline_state["done"],
            "result": pipeline_state["result"],
        }))


@app.route("/api/download")
def download():
    """Tải file Excel kết quả."""
    output_file = OUTPUT_FOLDER / "KetQua_GiaHoa.xlsx"
    if not output_file.exists():
        return jsonify({"error": "Chưa có file kết quả"}), 404
    return send_from_directory(str(OUTPUT_FOLDER), "KetQua_GiaHoa.xlsx",
                               as_attachment=True)


if __name__ == "__main__":
    print("=" * 50)
    print("  GIA HÒA — AI Agent Đánh Giá Chương Trình")
    print("  http://localhost:5000")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
