# Agent Đánh Giá Chương Trình Bán Hàng - Công Ty Gia Hòa

AI Agent sử dụng Google Gemini để tự động phân tích hiệu quả 4 chương trình bán hàng.

## Cài đặt

```bash
cd gia-hoa-agent
pip install -r requirements.txt
```

## Chạy

```bash
export GEMINI_API_KEY='your-api-key-here'
python agent.py
```

## Kiến trúc

```
agent.py                  ← Orchestrator (Gemini function calling)
tools/
  data_loader.py          ← Bước 1: Kiểm tra dữ liệu
  revenue_allocator.py    ← Bước 2: Phân bổ doanh thu
  program_calculator.py   ← Bước 3: Tính kết quả
  reconciler.py           ← Bước 4: Đối soát & xuất file
data/
  Du_Lieu_Gia_Hoa.xlsx    ← Dữ liệu đầu vào
output/
  KetQua_GiaHoa.xlsx      ← Kết quả (tự động tạo)
```

## Quy trình xử lý

1. **Tiếp nhận & kiểm tra**: Đọc 4 sheet, loại 137 đơn mã trống/NONE
2. **Phân bổ doanh thu**: Đơn 1 mã → gán trọn; đơn nhiều mã → chia đều 1/N; trừ đổi trả
3. **Tính kết quả**: Doanh thu thuần - Giá vốn thuần - Chi phí cố định = Phần đóng góp
4. **Đối soát & xuất**: Kiểm tra tổng khớp → Xuất Excel 4 sheet
